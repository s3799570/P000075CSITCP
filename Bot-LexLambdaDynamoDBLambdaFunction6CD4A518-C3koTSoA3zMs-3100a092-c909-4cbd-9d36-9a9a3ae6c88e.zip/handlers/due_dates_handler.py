# import logging
# logger = logging.getLogger(__name__)

import boto3
from boto3.dynamodb.conditions import Key

from helpers.helpers import createTableIfNew
from helpers.helpers import getFirstName
from helpers.helpers import courseExists

dynamodb = boto3.resource("dynamodb",region_name="ap-southeast-2")
dynamodbclient = boto3.client("dynamodb",region_name="ap-southeast-2")
assignmentTableName = "Assignments"
courseTableName = "Courses"

def handle_due_dates(intent_request):
    createTableIfNew()
    intent = intent_request["sessionState"]["intent"]
    courseID = intent["slots"]["CourseID"]["value"]["originalValue"].upper()

    result = ""
    # result += str(intent_request)
    actionType = "ConfirmIntent"
    assignmentNames = ""
    
    firstName = getFirstName(intent_request)
    if firstName != "":
        result += firstName+", "
    
    assignmentTable = dynamodb.Table(assignmentTableName)
    # Get all rows where course_id matches
    assignmentQuery = assignmentTable.query(
        KeyConditionExpression=Key('course_id').eq(courseID)
    )['Items']


    if courseExists(courseID):
        try:
            # If the requested course has assignments
            if len(assignmentQuery) > 0:
                result += "Course "+courseID+" has the following assignments: "
                for row in assignmentQuery:
                    result += "\n" + row['assignment_name'] + " due on " + row['assignment_due_date'] + " at " + row['assignment_due_time']
                    
            else:
                result += "I do not know about any assignments for course " + courseID
                
        except Exception as e:
            result += "ERROR: " + str(e)
        
    else:
        result += "the course you requested information about does not exist"
    
    # CODE FOR SPLITTING MESSAGES INTO MULTIPLE MESSAGES BASED ON NEWLINES
    splitString = result.split('\n')
    m=[]
    m.append({
        "contentType": "PlainText",
        "content": result,
    },)
    # for line in splitString:
    #     m.append(
    #         {
    #             "contentType": "PlainText",
    #             "content": line,
    #         },)
    
    
    
    intent["state"] = "Fulfilled"

    # lang = intent_request["bot"]["localeId"]
    return {
        "sessionState": {
            "dialogAction": {
                "type": "Close"
                # "type": actionType,
                # 'intentName': "AssignmentInfo",
                # 'slots': {
                #     "AssignmentNames" : assignmentNames
                #     },
                # 'message': {
                #     'contentType': 'PlainText',
                #     'content': result
                # }
            },

            "intent": intent,
        },
        "messages": m,
        "sessionId": intent_request["sessionId"],
        # "sessionAttributes": {
        #   "attributeName": "attributeValue",
        #   "attributeName": "attributeValue"
        # },
        "requestAttributes": intent_request["requestAttributes"]
        if "requestAttributes" in intent_request
        else None,
        
    }
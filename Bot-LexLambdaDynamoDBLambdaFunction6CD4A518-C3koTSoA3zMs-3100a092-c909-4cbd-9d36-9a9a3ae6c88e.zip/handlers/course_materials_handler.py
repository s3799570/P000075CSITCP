# import logging
# logger = logging.getLogger(__name__)

import boto3
from boto3.dynamodb.conditions import Key

from helpers.helpers import getFirstName
from helpers.helpers import createTableIfNew
from helpers.helpers import courseExists


dynamodb = boto3.resource("dynamodb",region_name="ap-southeast-2")
dynamodbclient = boto3.client("dynamodb",region_name="ap-southeast-2")

courseMaterialsTableName = "CourseMaterials"

def handle_course_materials(intent_request):
    createTableIfNew()
    intent = intent_request["sessionState"]["intent"]
    courseID = intent["slots"]["CourseID"]["value"]["originalValue"].upper()

    result = ""
    
    courseMatTable = dynamodb.Table(courseMaterialsTableName)
    # Get all rows where course_id matches
    courseMatQuery = courseMatTable.query(
        KeyConditionExpression=Key('course_id').eq(courseID)
    )['Items']
    
    firstName = getFirstName(intent_request)
    if firstName != "":
        result += firstName+", "
    
    if courseExists(courseID):
        try:
            # If the requested course has materials
            if len(courseMatQuery) > 0:
                result += "I found the following materials for course "+courseID
                for row in courseMatQuery:
                    result += "\n" + row['material_name'] + ": " + row['link']
                
            else:
                # If the course has no materials in the course materials table
                result += "I do not know about any materials for course " + courseID
                
        except Exception as e:
            result += "ERROR: " + str(e)

    else:
        result += "the course you requested materials from does not exist"
    
    
    
    intent["state"] = "Fulfilled"

    # lang = intent_request["bot"]["localeId"]
    return {
        "sessionState": {
            "dialogAction": {"type": "Close"},
            "intent": intent,
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": result,
            }
        ],
        "sessionId": intent_request["sessionId"],
        "requestAttributes": intent_request["requestAttributes"]
        if "requestAttributes" in intent_request
        else None,
    }
    

import boto3
from boto3.dynamodb.conditions import Key

from helpers.helpers import createTableIfNew
from helpers.helpers import getFirstName
from helpers.helpers import isTeacher

dynamodb = boto3.resource("dynamodb",region_name="ap-southeast-2")
dynamodbclient = boto3.client("dynamodb",region_name="ap-southeast-2")
courseWorkQueryTableName = "CourseWorkQueries"


def handle_get_unanswered(intent_request):
    createTableIfNew()
    intent = intent_request["sessionState"]["intent"]
    courseID = intent["slots"]["CourseID"]["value"]["originalValue"].upper()

    result = ""
    
    if not isTeacher(intent_request):
        result = "You are not authorised to access this resource"
        
    else:
        courseWorkTable = dynamodb.Table(courseWorkQueryTableName)
        # Get all rows where course_id matches
        courseWorkQuery = courseWorkTable.query(
            KeyConditionExpression=Key('course_id').eq(courseID)
        )['Items']
        
        firstName = getFirstName(intent_request)
        if firstName != "":
            result += firstName+", "
        
        try:
            # If the requested course has questions
            if len(courseWorkQuery) > 0:
                unansweredQuestions = ""
                for row in courseWorkQuery:
                    if row["answer"] == "":
                        unansweredQuestions += "\n"+row["question"]
                
                if unansweredQuestions != "":
                    result += "course " + courseID + " has the following unanswered questions: "
                    result += unansweredQuestions
                        
                else:
                    result += "course " + courseID + " has no unanswered questions"
                    
            else:
                result += "course " + courseID + " has no questions"
        
        except Exception as e:
            result += "ERROR: " + str(e)
                
    intent["state"] = "Fulfilled"

    return {
        "sessionState": {
            "dialogAction": {"type": "Close"},
            "intent": intent,
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": result,
            }
        ],
        "sessionId": intent_request["sessionId"],
        "requestAttributes": intent_request["requestAttributes"]
        if "requestAttributes" in intent_request
        else None,
    }
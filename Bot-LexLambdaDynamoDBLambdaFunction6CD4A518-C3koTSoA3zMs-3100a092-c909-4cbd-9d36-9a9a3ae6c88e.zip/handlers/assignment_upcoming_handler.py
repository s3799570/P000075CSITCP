# import logging
# logger = logging.getLogger(__name__)

import boto3
from datetime import datetime

dynamodb = boto3.resource("dynamodb",region_name="ap-southeast-2")
dynamodbclient = boto3.client("dynamodb",region_name="ap-southeast-2")
assignmentTableName = "Assignments"
courseTableName = "Courses"

def handle_upcoming_assignments(intent_request):
    intent = intent_request["sessionState"]["intent"]
    actionType = "ConfirmIntent"
    currentTime = datetime.now()

    result = ""
    actionType = "ConfirmIntent"
    
    assignments = dynamodb.Table(assignmentTableName)
    try:
        assignments = dynamodb.Table(assignmentTableName)
        query = assignments.scan()["Items"]

        upcomingAssignments = ""
        aDue = ""
        aDueDate = ""

        for item in query:
            aDue = item['assignment_due_date']
            aDueDate = datetime.strptime(aDue, '%d/%m/%Y')
            if aDueDate != "" and currentTime < aDueDate:
                upcomingAssignments += "- on " + aDue + ", " + item['assignment_name'] + " for " + item['course_id'] + " is due.\n\n"

                
        if upcomingAssignments != "":
            # result += "The following assignments are due soon: "
            result += upcomingAssignments
        else:
            result = "You have no upcoming assignments. Hooray!"
            actionType = "Close"
        
    except Exception as e:
        result += "ERROR: " + str(e)
    
    

    intent["state"] = "Fulfilled"

    # lang = intent_request["bot"]["localeId"]
    return {
        "sessionState": {
            "dialogAction": {
                "type": "Close"
                # "type": actionType,
                # 'intentName': "Assignment_Upcoming",
                # 'slots': {
                #     "AssignmentNames" : assignmentNames
                #     },
                # 'message': {
                #     'contentType': 'PlainText',
                #     'content': result
                # }
            },

            "intent": intent,
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": result,
            }
        ],
        "sessionId": intent_request["sessionId"],
        # "sessionAttributes": {
        #   "attributeName": "attributeValue",
        #   "attributeName": "attributeValue"
        # },
        "requestAttributes": intent_request["requestAttributes"]
        if "requestAttributes" in intent_request
        else None,
        
    }
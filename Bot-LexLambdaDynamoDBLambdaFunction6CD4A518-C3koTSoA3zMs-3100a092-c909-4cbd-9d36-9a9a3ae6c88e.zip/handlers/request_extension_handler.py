# import logging
# logger = logging.getLogger(__name__)

import boto3
from datetime import datetime

dynamodb = boto3.resource("dynamodb",region_name="ap-southeast-2")
dynamodbclient = boto3.client("dynamodb",region_name="ap-southeast-2")
assignmentTableName = "Assignments"
courseTableName = "Courses"

def handle_request_extension(intent_request):
    intent = intent_request["sessionState"]["intent"]
    courseID = intent["slots"]["code"]["value"]["originalValue"].upper()
    number = intent["slots"]["number"]["value"]["originalValue"].upper()

    result = ""
    
    actionType = "ConfirmIntent"
    
    currentTime = datetime.now()

    assignments = dynamodb.Table(assignmentTableName)
    try:
        query = assignments.scan()["Items"]
        assignDue = ""
        dueDate = ""
        requestResult = ""
        contactInfo = ""
        
        for item in query:
            if item['course_id'] == courseID and item['assignment_number'] == number:
                assignDue += item['assignment_due_date']
                dueDate = datetime.strptime(assignDue, '%d/%m/%Y')
                requestResult += item['assignment_name']
                contactInfo += item['contact_info']
                
        if dueDate != "" and currentTime < dueDate:
            result += "For the course " + courseID + " and Assignment " + number + "\nYou will have to fill the extension form! \nBefore you fill the form, ensure you have the supporting documents ready (e.g. Medical Certificate).\nPlease submit the form at least ONE WORKING DAY before the deadline! \nHere is the link to download the form https://www.rmit.edu.au/students/my-course/assessment-results/special-consideration-extensions/extensions\n\nPlease submit the form to your Course tutor\n" + contactInfo
        elif dueDate != "" and currentTime >= dueDate:
            result += "For the course " + courseID + " and Assignment " + number + "\nYou will have to fill the Special Consideration form! \nBefore you fill the form, ensure that you have the supporting documents ready (e.g. Medical Certificate). \n Here is the link to the form https://www.rmit.edu.au/students/my-course/assessment-results/special-consideration-extensions/special-consideration\n\nPlease submit the form to your Course tutor\n" + contactInfo
        else:
            result = "I don't have Assignment " + number + " from the Course " + courseID + " in my database "
            actionType = "Close"

        # result+=str(query)
    except Exception as e:
        result += "ERROR: " + str(e)

    intent["state"] = "Fulfilled"

    # lang = intent_request["bot"]["localeId"]
    return {
        "sessionState": {
            "dialogAction": {
                "type": "Close"
                # "type": actionType,
                # 'intentName': "RequestInfo",
                # 'slots': {
                #     "RequestResult" : requestResult
                #     },
                # 'message': {
                #     'contentType': 'PlainText',
                #     'content': result
                # }
            },

            "intent": intent,
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": result,
            }
        ],
        "sessionId": intent_request["sessionId"],
        # "sessionAttributes": {
        #   "attributeName": "attributeValue",
        #   "attributeName": "attributeValue"
        # },
        "requestAttributes": intent_request["requestAttributes"]
        if "requestAttributes" in intent_request
        else None,
    }
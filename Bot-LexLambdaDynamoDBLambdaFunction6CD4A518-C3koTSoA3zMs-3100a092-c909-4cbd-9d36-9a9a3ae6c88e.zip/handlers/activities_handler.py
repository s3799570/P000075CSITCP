# import logging
# logger = logging.getLogger(__name__)

import boto3
from datetime import datetime

dynamodb = boto3.resource("dynamodb",region_name="ap-southeast-2")
dynamodbclient = boto3.client("dynamodb",region_name="ap-southeast-2")
assignmentTableName = "Activities"

def handle_activities(intent_request):
    intent = intent_request["sessionState"]["intent"]
    actionType = "ConfirmIntent"
    currentDay = datetime.now().strftime("%A")
    actionType = "ConfirmIntent"
    
    result = ""
    activities = dynamodb.Table(assignmentTableName)
    try:
        activities = dynamodb.Table(assignmentTableName)
        query = activities.scan()["Items"]

        upcomingActivities = []

        # collect classes for the day into a list of dictionaries
        for item in query:
            day = item['day']
            if day != "" and day == currentDay:
                i = {
                    "time": item['time'],
                    "type": item['type'],
                    "campus": item['campus'],
                    "location": item['location'],
                    "course_id": item['course_id']
                }
                
                upcomingActivities.append(i)

        # bubble sort - sort activities by their time
        n = len(upcomingActivities)
        for i in range(n-1):
            for j in range(0, n-i-1):
                time1 = datetime.strptime(upcomingActivities[j]["time"], '%H:%M')
                time2 = datetime.strptime(upcomingActivities[j+1]["time"], '%H:%M')
                if time1 > time2 :
                    upcomingActivities[j], upcomingActivities[j + 1] = upcomingActivities[j + 1], upcomingActivities[j]
        
        # append result of sorted activities
        if upcomingActivities != "":
            for item in upcomingActivities:
                result += "At " + item["time"] + " you have a " + item["type"] + " for " + item["course_id"] + " "
                if item["campus"].lower() == "canvas":
                    result += "on Canvas. "
                else:
                    result += "in " + item["campus"] + " at " + item["location"] + ". "
        else:
            result = "You have no classes scheduled for today."
            actionType = "Close"
        
    except Exception as e:
        result += "ERROR: " + str(e)
    
    
    intent["state"] = "Fulfilled"

    # lang = intent_request["bot"]["localeId"]
    return {
        "sessionState": {
            "dialogAction": {
                "type": "Close"
                # "type": actionType,
                # 'intentName': "Assignment_Upcoming",
                # 'slots': {
                #     "AssignmentNames" : assignmentNames
                #     },
                # 'message': {
                #     'contentType': 'PlainText',
                #     'content': result
                # }
            },

            "intent": intent,
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": result,
            }
        ],
        "sessionId": intent_request["sessionId"],
        # "sessionAttributes": {
        #   "attributeName": "attributeValue",
        #   "attributeName": "attributeValue"
        # },
        "requestAttributes": intent_request["requestAttributes"]
        if "requestAttributes" in intent_request
        else None,
        
    }
# import logging
# logger = logging.getLogger(__name__)

import boto3
from boto3.dynamodb.conditions import Key

from helpers.helpers import getFirstName
from helpers.helpers import createTableIfNew
from helpers.helpers import courseExists


dynamodb = boto3.resource("dynamodb",region_name="ap-southeast-2")
dynamodbclient = boto3.client("dynamodb",region_name="ap-southeast-2")

courseWorkQueryTableName = "CourseWorkQueries"

def handle_course_work_query(intent_request):
    createTableIfNew()
    intent = intent_request["sessionState"]["intent"]
    courseID = intent["slots"]["CourseID"]["value"]["originalValue"].upper()
    
    # TODO: Extract keywords from question instead of asking for keywords
    keywords = intent["slots"]["Keywords"]["value"]["originalValue"].upper().split()

    result = ""
    
    courseWorkTable = dynamodb.Table(courseWorkQueryTableName)
    # Get all rows where course_id matches
    courseWorkQuery = courseWorkTable.query(
        KeyConditionExpression=Key('course_id').eq(courseID)
    )['Items']
    
    firstName = getFirstName(intent_request)
    if firstName != "":
        result += firstName+", "
    
    if courseExists(courseID):
        try:
            # If the requested course has questions
            if len(courseWorkQuery) > 0:
                answers = ""
                for row in courseWorkQuery:
                    # If the questions contain one of the keywords and the question has an answer
                    if any(keyword in row['question'].upper() for keyword in keywords) and row['answer'] != "":
                        answers += "\nIn response to \"" + row['question'] + "\":\n" + row['answer']
                
                if answers != "":
                    # If there were questions containing the keywords that have answers
                    result += "I found the following answers related to your query for course "+courseID
                    result += answers
                
                else:
                    # If there were no questions containing the keywords that have answers
                    result += "I do not know anything about course "+courseID+ " related to your keywords"
                
            else:
                # If the course has no questions in the coursework queries table
                result += "I do not know about anything about course " + courseID
                
        except Exception as e:
            result += "ERROR: " + str(e)

    else:
        result += "the course you requested information about does not exist"
    
    
    
    intent["state"] = "Fulfilled"

    # lang = intent_request["bot"]["localeId"]
    return {
        "sessionState": {
            "dialogAction": {"type": "Close"},
            "intent": intent,
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": result,
            }
        ],
        "sessionId": intent_request["sessionId"],
        "requestAttributes": intent_request["requestAttributes"]
        if "requestAttributes" in intent_request
        else None,
    }
    

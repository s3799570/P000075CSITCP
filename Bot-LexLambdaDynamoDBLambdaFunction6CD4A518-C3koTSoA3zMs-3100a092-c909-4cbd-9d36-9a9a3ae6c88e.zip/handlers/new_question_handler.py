from helpers.helpers import createTableIfNew
from helpers.helpers import courseExists

import boto3

courseWorkQueryTableName = "CourseWorkQueries"

dynamodb = boto3.resource("dynamodb",region_name="ap-southeast-2")
dynamodbclient = boto3.client("dynamodb",region_name="ap-southeast-2")

def handle_new_question(intent_request):
    intent = intent_request["sessionState"]["intent"]

    courseID = intent["slots"]["CourseID"]["value"]["originalValue"].upper()
    question = intent["slots"]["Question"]["value"]["originalValue"]
    
    if courseExists(courseID):
        # Convert question into multiple words
        # TODO: Change slot type to accept multiple words
        x=0
        y=len(question)
        while x < y:
            if question[x].isupper():
                question = question[0:x]+" "+question[x:]
                y+=1
                x+=1
            x+=1
    
        question = question.strip()
    
        courseWorkQueryTable = dynamodb.Table(courseWorkQueryTableName)
        courseWorkQueryTable.put_item(
            Item={
                "course_id" : courseID,
                "question" : question,
                "answer" : ""
            }
        )
        
        result = "Your question has been submitted"
        
    else:
        result = "the course you have a question for does not exist"
    
    intent["state"] = "Fulfilled"

    # lang = intent_request["bot"]["localeId"]
    return {
        "sessionState": {
            "dialogAction": {"type": "Close"},
            "intent": intent,
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": result,
            }
        ],
        "sessionId": intent_request["sessionId"],
        "requestAttributes": intent_request["requestAttributes"]
        if "requestAttributes" in intent_request
        else None,
    }
import boto3
from boto3.dynamodb.conditions import Key

from helpers.helpers import createTableIfNew
from helpers.helpers import getFirstName
from helpers.helpers import courseExists

dynamodb = boto3.resource("dynamodb",region_name="ap-southeast-2")
dynamodbclient = boto3.client("dynamodb",region_name="ap-southeast-2")
assignmentTableName = "Assignments"
courseTableName = "Courses"

def handle_assignment_info(intent_request):
    createTableIfNew()
    intent = intent_request["sessionState"]["intent"]
    courseID = intent["slots"]["CourseID"]["value"]["originalValue"].upper()
    assignmentNumber = intent["slots"]["AssignmentNumber"]["value"]["originalValue"].upper()

    result = ""
    # result += str(intent_request)
    actionType = "ConfirmIntent"
    assignmentNames = ""
    
    firstName = getFirstName(intent_request)
    if firstName != "":
        result += firstName+", "
    
    # SUGGESTION: refactor assignments table so assignment number is also a key for faster access/cleaner code
    assignmentTable = dynamodb.Table(assignmentTableName)
    # Get all rows where course_id matches
    assignmentQuery = assignmentTable.query(
        KeyConditionExpression=Key('course_id').eq(courseID)
    )['Items']


    if courseExists(courseID):
        try:
            # If the requested course has assignments
            if len(assignmentQuery) > 0:
                found = False
                for row in assignmentQuery:
                    if row["assignment_number"] == assignmentNumber:
                        result += "\nAssignment Name: "+ row['assignment_name']
                        result += "\nAssignment Due: "+ row['assignment_due_date'] + " at " + row['assignment_due_time']
                        result += "\nContact: "+ row['contact_info']
                        result += "\nDescription: "+ row['description']
                        result += "\nSubmitting: "+ row['submitting']
                        result += "\nFile Types: "+ row['file_types']
                        result += "\nPoints: "+ row['points']
                        found = True
                        break
                    
                if not found:
                    result += "I could not find assignment " + assignmentNumber + " for course " + courseID
                    
            else:
                result += "I do not know about any assignments for course " + courseID
                
        except Exception as e:
            result += "ERROR: " + str(e)
        
    else:
        result += "the course you requested information about does not exist"
    
    m=[]
    m.append({
        "contentType": "PlainText",
        "content": result,
    },)

    
    intent["state"] = "Fulfilled"

    # lang = intent_request["bot"]["localeId"]
    return {
        "sessionState": {
            "dialogAction": {
                "type": "Close"
            },

            "intent": intent,
        },
        "messages": m,
        "sessionId": intent_request["sessionId"],
        # "sessionAttributes": {
        #   "attributeName": "attributeValue",
        #   "attributeName": "attributeValue"
        # },
        "requestAttributes": intent_request["requestAttributes"]
        if "requestAttributes" in intent_request
        else None,
        
    }
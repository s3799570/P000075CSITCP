import boto3
from datetime import datetime

dynamodb = boto3.resource("dynamodb",region_name="ap-southeast-2")
dynamodbclient = boto3.client("dynamodb",region_name="ap-southeast-2")
FallbackDatabase = "Fallback"

def handle_fallback_intent(intent_request):
    
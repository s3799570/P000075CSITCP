import boto3
from boto3.dynamodb.conditions import Key


dynamodb = boto3.resource("dynamodb",region_name="ap-southeast-2")
dynamodbclient = boto3.client("dynamodb",region_name="ap-southeast-2")
assignmentTableName = "Assignments"
courseTableName = "Courses"
courseWorkQueryTableName = "CourseWorkQueries"
userTableName = "Users"
courseMaterialsTableName = "CourseMaterials"

def levenshtein_difference(s1,s2):
    len1 = len(s1)
    len2 = len(s2)
    
    matrix = [[0 for x in range(len2)] for y in range(len1)]
    mindist = float('-inf')
    
    for x in range(len1):
        matrix[x][0] = x
    for y in range(len2):
        matrix[0][y] = y
    
    for x in range(1,len1):
        for y in range(1,len2):
            if s1[x-1] == s2[y-1]:
                matrix[x][y] = min(matrix[x-1][y-1],matrix[x-1][y],matrix[x][y-1])
            else:
                matrix[x][y] = min(matrix[x-1][y-1],matrix[x-1][y],matrix[x][y-1])+1
                
    return matrix[len1-1][len2-1]
    
    
# Gets firstname from intent_request
def getFirstName(intent_request):
    try:
        email = intent_request["requestAttributes"]["email"]
        
        userTable = dynamodb.Table(userTableName)
        userQuery = userTable.query(
            KeyConditionExpression=Key('email').eq(email)
        )['Items']
        
        if len(userQuery) > 0:
            # If the user is in the users table
            return userQuery[0]["first_name"]
            
    # raised when using test console
    except KeyError:
        pass
    
    return ""
    
    
def isTeacher(intent_request):
    try:
        email = intent_request["requestAttributes"]["email"]
        
        userTable = dynamodb.Table(userTableName)
        userQuery = userTable.query(
            KeyConditionExpression=Key('email').eq(email)
        )['Items']
        
        if len(userQuery) > 0:
            # If the user is in the users table
            return userQuery[0]["type"] == "Teacher"
            
    # raised when using test console
    except KeyError:
        pass
    
    # POSSIBLY REMOVE TRY/EXCEPT FOR BETTER HANDLING
    return True
    
    
# Returns true if the course is found in the courses table, false otherwise
def courseExists(courseID):
    courseTable = dynamodb.Table(courseTableName)
    courseQuery = courseTable.query(
        KeyConditionExpression=Key('course_id').eq(courseID)
    )['Items']
    
    return len(courseQuery) > 0

    
def createTableIfNew():
    # Create the Assignments table if it doesnt already exist
    try:
        table = dynamodb.create_table(
        TableName=assignmentTableName,
        KeySchema=[
            {
                'AttributeName': 'course_id',
                'KeyType': 'HASH'
            },
            {
                'AttributeName': 'assignment_name',
                'KeyType': 'RANGE'
            },
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'course_id',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'assignment_name',
                'AttributeType': 'S'
            },
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 5,
            'WriteCapacityUnits': 5
        })
        
        table.wait_until_exists()
        
    except dynamodbclient.exceptions.ResourceInUseException:
        pass
    
    # Create the Courses table if it doesnt already exist
    try:
        table = dynamodb.create_table(
        TableName=courseTableName,
        KeySchema=[
            {
                'AttributeName': 'course_id',
                'KeyType': 'HASH'
            },
            {
                'AttributeName': 'course_name',
                'KeyType': 'RANGE'
            },
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'course_id',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'course_name',
                'AttributeType': 'S'
            },
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 5,
            'WriteCapacityUnits': 5
        })
        
        table.wait_until_exists()
        
    except dynamodbclient.exceptions.ResourceInUseException:
        pass
    
    # Create the CourseWorkQuery table if it doesnt already exist
    try:
        table = dynamodb.create_table(
        TableName=courseWorkQueryTableName,
        KeySchema=[
            {
                'AttributeName': 'course_id',
                'KeyType': 'HASH'
            },
            {
                'AttributeName': 'question',
                'KeyType': 'RANGE'
            },
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'course_id',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'question',
                'AttributeType': 'S'
            },
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 5,
            'WriteCapacityUnits': 5
        })
        
        table.wait_until_exists()
        
    except dynamodbclient.exceptions.ResourceInUseException:
        pass
    
    # Create Users table if it does not exist
    try:
        table = dynamodb.create_table(
        TableName=userTableName,
        KeySchema=[
            {
                'AttributeName': 'email',
                'KeyType': 'HASH'
            },
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'email',
                'AttributeType': 'S'
            },
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 5,
            'WriteCapacityUnits': 5
        })
        
        table.wait_until_exists()
        
    except dynamodbclient.exceptions.ResourceInUseException:
        pass
    
    # Create course materials table if it does not exist
    try:
        table = dynamodb.create_table(
        TableName=userTableName,
        KeySchema=[
            {
                'AttributeName': 'course_id',
                'KeyType': 'HASH'
            },
            {
                'AttributeName': 'material_name',
                'KeyType': 'RANGE'
            },
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'course_id',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'material_name',
                'AttributeType': 'S'
            },
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 5,
            'WriteCapacityUnits': 5
        })
        
        table.wait_until_exists()
        
    except dynamodbclient.exceptions.ResourceInUseException:
        pass
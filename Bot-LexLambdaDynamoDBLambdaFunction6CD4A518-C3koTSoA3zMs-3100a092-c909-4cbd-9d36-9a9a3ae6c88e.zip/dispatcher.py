######################################################################################################################
#  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.                                                #
#                                                                                                                    #
#  Licensed under the Apache License, Version 2.0 (the 'License'). You may not use this file except in compliance    #
#  with the License. A copy of the License is located at                                                             #
#                                                                                                                    #
#      http://www.apache.org/licenses/LICENSE-2.0                                                                    #
#                                                                                                                    #
#  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES #
#  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions    #
#  and limitations under the License.                                                                                #
#                                                                                                                    #
#  Modified by Dichen Hu, Evan Mason, Victoria Benn, Nicolas Steven, Allan Paul                                      #
######################################################################################################################
import logging

from handlers.due_dates_handler import handle_due_dates
from handlers.course_work_query_handler import handle_course_work_query
from handlers.assignment_info_handler import handle_assignment_info
from handlers.request_extension_handler import handle_request_extension
from handlers.assignment_upcoming_handler import handle_upcoming_assignments
from handlers.new_question_handler import handle_new_question
from handlers.get_unanswered_handler import handle_get_unanswered
from handlers.activities_handler import handle_activities
from handlers.course_materials_handler import handle_course_materials
#from fallback.new_fallback_handler import handle_fallback_intent

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    '''
    Main handler function for the Lambda function that is integrated with Amazon Lex. Calls proper handler function based on detected intent from Amazon Lex.

    :param event: Event object that was sent by Amazon Lex
    :param context: Context object constructed by AWS Lambda service
    :returns: Constructed response object with compatible format to send to Amazon Lex.
    '''
    intent_name = event["sessionState"]["intent"]["name"]
    logger.info(f"Lex event with Intent Name: {intent_name}")
        
    # JH-75-Chatbot
    if intent_name == "Assignment_DueDates":
        return handle_due_dates(event)
    elif intent_name == "Course_Queries":
        return handle_course_work_query(event)
    elif intent_name == "Assignment_Info":
        return handle_assignment_info(event)
    elif intent_name == "Assignment_Extension":
        return handle_request_extension(event)
    elif intent_name == "Assignment_Upcoming":
        return handle_upcoming_assignments(event)
    elif intent_name == "NewQuestion":
        return handle_new_question(event)
    elif intent_name == "GetUnansweredQuestions":
        return handle_get_unanswered(event)
    elif intent_name == "Activities":
        return handle_activities(event)
    elif intent_name == "CourseMaterials":
        return handle_course_materials(event)
#   elif intent_name == "FallbackIntent":
#       return handle_fallback_intent(event)


    raise Exception(f"Intent with name {intent_name} not supported")
